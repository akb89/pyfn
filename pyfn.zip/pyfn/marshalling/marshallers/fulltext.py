"""Marshall AnnotationSets to FN fulltext XML files."""

__all__ = ['marshall_to_fulltext_xml']


def marshall_to_fulltext_xml():
    """Marshall a list of AnnotationSets to a FN fulltext XML file."""
    return
