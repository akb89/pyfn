"""Unmarshall frame.xml file."""

__all__ = ['unmarshall_frame_xml']


def unmarshall_frame_xml():
    """Return a {fe_id: FrameElement} dict."""
    return
